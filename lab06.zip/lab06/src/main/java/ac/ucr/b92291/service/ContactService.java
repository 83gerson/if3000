package ac.ucr.b92291.service;

import ac.ucr.b92291.domain.Contact;
import acucr.b92291.persistence.Persistence;
import acucr.b92291.persistence.PersistenceContext;

import java.util.List;

public class ContactService {

    private final Persistence<Contact> persistence = PersistenceContext
            .getInstance()
            .getPersistenceInstance(Contact.class);

    public void save(Contact contact) {
        // validar inputs  ->
        // retornando algún tipo de valor diferente o lanzando una excepcion personalizada
        persistence.save(contact);
    }

    public List<Contact> findAll() {
        return persistence.findAll();
    }
}
