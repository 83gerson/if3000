/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.lab02;

import java.util.HashSet;
import java.util.List;

/**
 *
 * @author Gerson Cordero
 */
public class App {

    public static void main(String[] args) {
        HashSet hashSet = new HashSet();
        
        
    }

}
