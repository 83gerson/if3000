/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.B92291.hw01;

import java.time.LocalDate;

/**
 *
 * @author Gerson Cordero
 */
public class App {

    public static void main(String args[]) {

        LotteryNumber first = new LotteryNumber(98, LocalDate.MAX);
        first.add(new LotteryNumber(03, LocalDate.MAX));
        first.add(new LotteryNumber(33, LocalDate.MAX));
        first.add(new LotteryNumber(45, LocalDate.MAX));
        first.add(new LotteryNumber(67, LocalDate.MAX));
        first.add(new LotteryNumber(98, LocalDate.MAX));
        first.print();
        System.out.println(first.find(12));

        System.out.println("----------searchOriginal----------");
        LotteryNumber second = new LotteryNumber(33, LocalDate.MAX);
        second.add(new LotteryNumber(12, LocalDate.MAX));
        second.add(new LotteryNumber(54, LocalDate.MAX));
        second.add(new LotteryNumber(89, LocalDate.MAX));
        second.add(new LotteryNumber(01, LocalDate.MAX));
        second.print();
        
         System.out.println(" ");
         System.out.println("----------searchGreaterThan----------");
         LotteryNumber greaterThan=second.searchGreaterThan(40);
         greaterThan.print();
 
         System.out.println(" ");
         System.out.println("----------searchLowerThan----------");
         LotteryNumber lowerThan=second.searchLowerThan(40);
         lowerThan.print();
    }

}
