package ac.ucr.b92291.ui;

import javafx.application.Platform;
import javafx.scene.control.Alert;

public class AlertUtil {

    public static void showSuccess(String message) {
        Platform.runLater(() -> {
            new Alert(Alert.AlertType.INFORMATION, message).show();
        });
    }

    public static void showError(String message) {
        Platform.runLater(() -> {
            new Alert(Alert.AlertType.ERROR, message).show();
        });
    }

}
