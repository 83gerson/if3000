package ac.ucr.b92291.common;


public class Response {
    // OK, ERROR ->Enum
    private String type;
    /**
     * OK: El Payload va a contener la respuesta esperada
     * <p>
     * ERROR: Tendrá algún mensaje o excepción
     */
    private String payload;

    public Response(String type, String payload) {
        this.type = type;
        this.payload = payload;
    }

    public Response() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public static class ResponseBuilder {

        private String type;
        private String payload;

        public static ResponseBuilder newBuilder() {
            return new ResponseBuilder();
        }

        public ResponseBuilder isSuccess() {
            type = "OK";
            return this;
        }

        public ResponseBuilder isError() {
            type = "ERROR";
            return this;
        }

        public ResponseBuilder withPayload(String payload) {
            this.payload = payload;
            return this;
        }

        public Response build() {
            return new Response(type, payload);
        }
    }
}