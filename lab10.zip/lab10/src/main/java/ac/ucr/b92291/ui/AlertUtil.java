package ac.ucr.b92291.ui;

import ac.ucr.b92291.common.exceptions.FieldRequiredException;
import javafx.application.Platform;
import javafx.scene.control.Alert;

public class AlertUtil {


    public static void showSuccess(String message) {
        Platform.runLater(
                () -> new Alert(Alert.AlertType.INFORMATION, message).show()
        );
    }

    public static void showError(String message) {
        Platform.runLater(
                () -> new Alert(Alert.AlertType.ERROR, message).show()
        );
    }

    public static void showError(String message, Throwable exception) {
        Platform.runLater(
                () -> {
                    if (exception != null) {
                        if (exception instanceof FieldRequiredException) {
                            new Alert(
                                    Alert.AlertType.ERROR,
                                    "El campo " + ((FieldRequiredException) exception).getField() + " es requerido"
                            ).show();
                        } else {
                            new Alert(Alert.AlertType.ERROR, message).show();
                        }
                    }

                }
        );
    }


}