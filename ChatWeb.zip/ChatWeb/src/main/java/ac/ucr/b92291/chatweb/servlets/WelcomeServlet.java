/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.chatweb.servlets;

import ac.ucr.b92291.chatweb.repository.UserRepository;
import ac.ucr.b92291.chatweb.repository.UserRepository.User;
import ac.ucr.b92291.chatweb.util.FileUtil;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Gerson Cordero
 */
public class WelcomeServlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        super.init();
        System.out.println("Inicializando Servlet de Bienvenida...");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.getWriter().println(FileUtil.readFromFile("welcome.html"));

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("fname");
        String lastName = req.getParameter("lname");
        String email = req.getParameter("email");

        UserRepository.getInstance().add(new User(name, lastName, email));
        resp.sendRedirect("room?email=" + email);
    }
}
