package ac.ucr.b92291.server;


import ac.ucr.b92291.common.Configuration;
import ac.ucr.b92291.persistence.PersistenceContext;
import ac.ucr.b92291.persistence.PersistenceStrategy;

import java.io.File;
import java.io.IOException;

import static ac.ucr.b92291.common.Configuration.*;

public class ServerApp {
    public static void main(String[] args) throws IOException {
        Configuration.loadConfiguration("server.properties");
        PersistenceContext.getInstance().setRoot(new File(Configuration.get(ROOT)).getCanonicalPath());
        PersistenceContext.getInstance().setStrategy(
                PersistenceStrategy.valueOf(Configuration.get(STRATEGY))
        );
        new Server(Integer.parseInt(Configuration.get(PORT)));

    }
}