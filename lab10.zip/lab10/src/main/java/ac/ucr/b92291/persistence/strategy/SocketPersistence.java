package ac.ucr.b92291.persistence.strategy;

import ac.ucr.b92291.common.Request;
import ac.ucr.b92291.common.Response;
import ac.ucr.b92291.common.json.Json;
import ac.ucr.b92291.persistence.Persistence;
import ac.ucr.b92291.persistence.PersistenceEntity;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

public class SocketPersistence<E extends PersistenceEntity> implements Persistence<E> {

    protected final Class<E> clazz;

    public SocketPersistence(Class<E> clazz) {
        this.clazz = clazz;
    }

    @Override
    public E save(E value) {
        Request request = Request.RequestBuilder.newBuilder()
                .path(clazz.getSimpleName() + "/save")// Contact/save
                .payload(Json.convert(value))
                .build();
        sendRequest(request);
        return null;
    }

    private Response sendRequest(Request request) {
        //TODO pasar host y parámetros a los archivos de configuración
        Socket socket = null;
        try {
            socket = new Socket("127.0.0.1", 50001);

            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            out.writeObject(Json.convert(request));

            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            //necesitamos leer la respuesta
            return Json.toEntity(in.readObject().toString(), Response.class);

        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    @Override
    public List<E> findAll() {
        Request request = Request.RequestBuilder.newBuilder()
                .path(clazz.getSimpleName() + "/findAll")
                .build();
        Response response = sendRequest(request);
        return Json.readValueAsList(response.getPayload(), clazz); // -> es un String "[{..},{..}]"

    }
}