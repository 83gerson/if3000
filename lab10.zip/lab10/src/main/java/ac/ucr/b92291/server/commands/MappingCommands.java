package ac.ucr.b92291.server.commands;

import java.util.HashMap;
import java.util.Map;

public class MappingCommands {

    public static Map<String, Command> commands = new HashMap<>();

    static {
        commands.put("Contact/save", new ContactSaveCommand());
        commands.put("Contact/findAll", new ContactFindAllCommand());
    }

    public static Command getCommand(String path) {
        Command command = commands.get(path);
        if (command == null) {
            throw new RuntimeException("Comando no encontrado:" + path);
        }
        return command;
    }
}