/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.server;

import ac.ucr.b92291.common.Configuration;
import static ac.ucr.b92291.common.Configuration.PORT;
import ac.ucr.b92291.persistence.PersistenceContext;
import ac.ucr.b92291.persistence.PersistenceStrategy;

/**
 *
 * @author Gerson Cordero
 */
public class ServerApp {

    public static void main(String[] args) {
        Configuration.loadConfiguration("server.properties");
        PersistenceContext.getInstance().setRoot(Configuration.get(Configuration.ROOT));
        PersistenceContext.getInstance().setStrategy(PersistenceStrategy.valueOf(
                Configuration.get(Configuration.STRATEGY)));
        new Server(Integer.parseInt(Configuration.get(PORT)));
    }
}
