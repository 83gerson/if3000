package ac.ucr.b92291.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Configuration {

    public static final String ROOT = "app.persistence.root";
    public static final String STRATEGY = "app.persistence.strategy";
    public static final String PORT = "app.socket.port";

    //todos los metodos van a ser estáticos
    private static Properties applicationProp = new Properties();

    //metodo que va a cargar la configuracion
    public static void loadConfiguration(String props) {
        InputStream input = Configuration.class.getClassLoader().getResourceAsStream(props);
        try {
            applicationProp.load(input);
        } catch (IOException e) {
            throw new RuntimeException("No se pudo cargar el archivo properties", e);
        } finally {
            try {
                input.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static String get(String name) {
        return applicationProp.get(name).toString();
    }

}
