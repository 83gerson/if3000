/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.server.commands;

/**
 *
 * @author Gerson Cordero
 */
import java.util.HashMap;
import java.util.Map;

public class MappingCommands {

    public static Map<String, Command> commands = new HashMap<>();

    static {
        commands.put("Contact/save", new ContactSaveCommand());
    }

    public static Command getCommand(String path) {
        Command command = commands.get(path);
        if (command == null) {
            throw new RuntimeException("Comando no encontrado:" + path);
        }
        return command;
    }
}
