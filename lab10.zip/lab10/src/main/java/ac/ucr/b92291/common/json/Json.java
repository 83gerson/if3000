package ac.ucr.b92291.common.json;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.util.List;

/**
 * Utilitaria
 */
public class Json {
    //Cambios:
    // cambiar a public
    // agregar el static
    // Definir generic
    public static <E> String convert(E value) {
        try {
            return mapper().writerWithDefaultPrettyPrinter().writeValueAsString(value);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <E> E toEntity(String content, Class<E> clazz) {
        try {
            return mapper().readValue(content, clazz);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public static <E> List<E> readValueAsList(String entity, Class<E> clazz) {
        ObjectMapper mapper = mapper();
        //  Class<?> clz = Class.forName(clazz.getName());
        JavaType type = mapper.getTypeFactory()
                .constructCollectionType(List.class, clazz);
        try {
            return mapper.readValue(entity, type);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }

    }

    private static ObjectMapper mapper() {
        ObjectMapper mapper = new ObjectMapper();
        // Para poder convertir LocalDate
        mapper.registerModule(new JavaTimeModule());
        // Para evitar que falle cuando no encuentre una propiedad en un bean
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        // Para no escribir fechas como timestamps
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        return mapper;

    }

}