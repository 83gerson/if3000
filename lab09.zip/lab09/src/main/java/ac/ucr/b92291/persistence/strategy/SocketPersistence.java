/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.persistence.strategy;

import ac.ucr.b92291.common.Request;
import ac.ucr.b92291.common.Response;
import ac.ucr.b92291.common.json.Json;
import ac.ucr.b92291.persistence.Persistence;
import ac.ucr.b92291.persistence.PersistenceEntity;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

/**
 *
 * @author Gerson Cordero
 */
public class SocketPersistence<E extends PersistenceEntity> implements Persistence<E> {

    protected final Class<E> clazz;

    public SocketPersistence(Class<E> clazz) {
        this.clazz = clazz;
    }

    @Override
    public E save(E value) {
        Request request = Request.requestBuilder.newBuilder()
                .path(clazz.getSimpleName() + "/save") //Contact/save
                .payload(Json.convert(value))
                .build();

        sendRequest(request);
        //Crear un request
        //Convertirlo a Json
        //Enviarlo a través del socket
        return null;
    }

    private Response sendRequest(Request request) {
        Socket socket = null;
        try {
            socket = new Socket("127.0.0.1", 50001);

            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            out.writeObject(Json.convert(request));

            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

            return Json.toEntity(in.readObject().toString(), Response.class);

        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }

    }

    @Override
    public List<E> findAll() {
        return null;
    }

}
