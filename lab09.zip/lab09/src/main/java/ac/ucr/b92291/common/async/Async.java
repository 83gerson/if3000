package ac.ucr.b92291.common.async;

public interface Async<V> {
    //Va a tener 3 metodos, uno para ejecutar, otro para decir cuando es exitoso y otro por si falla.

    //ejecutar
    V execute();

    //exitoso
    void onSuccess(V response);

    //falla
    void onFail(Throwable fail);
}
