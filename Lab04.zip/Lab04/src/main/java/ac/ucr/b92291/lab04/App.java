/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.lab04;

import ac.ucr.b92291.lab04.domain.Contact;
import ac.ucr.b92291.lab04.persistence.PersistenceContext;
import ac.ucr.b92291.lab04.persistence.PersistenceStrategy;
import ac.ucr.b92291.lab04.service.ContactService;
import java.time.LocalDate;

/**
 *
 * @author Gerson Cordero
 */
public class App {

    public static void main(String[] args) {
        PersistenceContext.getInstance().setRoot("c:/data");
        PersistenceContext.getInstance().setStrategy(PersistenceStrategy.JSON);

        ContactService service = new ContactService();

        Contact c = new Contact();
        c.setBirthdate(LocalDate.now());
        c.setName("Miguel");
        c.setSurname("De Cervantes");
        service.save(c);

    }
}
