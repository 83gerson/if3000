package ac.ucr.b92291.common.async;

import java.util.function.Consumer;
import java.util.function.Supplier;

//se encarga de construir un objeto async y ejecutarlo
public class AsyncRunner<V> {
    private Supplier<V> onExecute;
    private Consumer<V> onSuccess;
    private Consumer<Throwable> onFail;

    // Se ejecuta en otro contexto
    // de ahí el porqué se declara otro generic
    public static <R> AsyncRunner<R> newRunner() {
        return new AsyncRunner<>();
    }

    public AsyncRunner<V> onExecute(Supplier<V> supplier) {
        onExecute = supplier;
        return this;
    }

    public AsyncRunner<V> onSuccess(Consumer<V> consumer) {
        onSuccess = consumer;
        return this;
    }

    public AsyncRunner<V> onFail(Consumer<Throwable> consumer) {
        onFail = consumer;
        return this;
    }

    public void run() {
        AsyncManager.execute(new Async<V>() {
            @Override
            public V execute() {
                return onExecute.get();
            }

            @Override
            public void onSuccess(V response) {
                if (onSuccess != null) {
                    onSuccess.accept(response);
                }
            }

            @Override
            public void onFail(Throwable fail) {
                onFail.accept(fail);
            }
        });

    }

}