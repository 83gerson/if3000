/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.chatweb.repository;

/**
 *
 * @author Gerson Cordero
 */
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class UserRepository {

    private Set<User> users;

    private static UserRepository instance;

    private UserRepository() {
        users = new HashSet<>();
    }

    public static UserRepository getInstance() {
        if (instance == null) {
            instance = new UserRepository();
        }
        return instance;
    }

    public synchronized void add(User user) {
        users.add(user);
    }

    public Set<User> all() {
        return users;
    }

    public User findByEmail(String email) {
        for (User user : users) {
            if (user.getEmail().equals(email)) {
                return user;
            }
        }
        return null;
    }

    public static class User {

        private String name;
        private String lastName;
        private String email;

        public User(String name, String lastName, String email) {
            this.name = name;
            this.lastName = lastName;
            this.email = email;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            User user = (User) o;
            return Objects.equals(email, user.email);
        }

        @Override
        public int hashCode() {
            return Objects.hash(email);
        }
    }

}
