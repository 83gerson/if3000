/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.lab04.service;

import ac.ucr.b92291.lab04.domain.Contact;
import ac.ucr.b92291.lab04.persistence.Persistence;
import ac.ucr.b92291.lab04.persistence.PersistenceContext;

/**
 *
 * @author Gerson Cordero
 */
public class ContactService {

    private final Persistence<Contact> persistence = PersistenceContext
            .getInstance()
            .getPersistenceInstance();

    public void save(Contact contact) {
        // validar inputs  ->
        // retornando algún tipo de valor diferente o lanzando una excepcion personalizada
        persistence.save(contact);
    }

}
