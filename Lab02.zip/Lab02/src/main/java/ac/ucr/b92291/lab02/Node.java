/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.lab02;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 *
 * @author Gerson Cordero
 */
public class Node {

    private String name;
    private boolean opinion;
    private boolean exposed;
    //HashSet hashSet = new HashSet();
    private Set<Node> friends;
    private Set<Node> friendsWhoAsks;

    public Node(String name) {
        this.name = name;
        opinion = false;
        exposed = false;
        //hashSet = null;
        friends = new HashSet<>();
    }

    public void add(Node friend) {

        if (friends.add(friend)) {
            friend.add(this);
        }

    }

    public String getNombre() {
        return name;
    }

    public boolean getOpinion(Node who) {

        if (friends.size() == friendsWhoAsks.size()) {
            return opinion;

        } else {
            friendsWhoAsks.add(who);
            return false;
        }
    }
//    public boolean isPublished() {
//        return published;
//    }
//
//    public void setPublished(boolean published) {
//        this.published = published;
//    }

// Events
    public void opinionPositive() {

        friendsWhoAsks.clear();
        opinion = true;
    }

    public void reviewOpinion() {
//        //Recorrer la lista usando streams y lambda
//        List opinions1 = friends.stream().filter(node -> node.getOpinion()).collect(Collectors.toList());
//        
//        //Recorrer la lista usando for
//        List<Boolean> opinions2 = new ArrayList();
//        for (Node node : friends) {
//            if (node.getOpinion()) {
//                opinions2.add(true);
//            }
//            
//        }

////Recorrer la lista usando streams y lambda
        //  Long opinion1 = friends.stream().filter(node -> node.getOpinion().count());
        
////Recorrer la lista usando for
        Long opinion2 = 0L;
        for (Node node : friends) {
//            if (node.getOpinion()) {
//                opinion2++;
//            }

        }
        if (friends.size() / 2 >= opinion2) {
            opinionPositive();
        }
    }

    @Override
    public boolean equals(Object obj) {

        return false;
    }

}
