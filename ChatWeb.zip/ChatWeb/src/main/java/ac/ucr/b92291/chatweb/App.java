/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.chatweb;

import ac.ucr.b92291.chatweb.servlets.QueryServlet;
import ac.ucr.b92291.chatweb.servlets.ResourceServlet;
import ac.ucr.b92291.chatweb.servlets.RoomServlet;
import ac.ucr.b92291.chatweb.servlets.WelcomeServlet;

/**
 * Hello world!
 */
public class App {

    public static void main(String[] args) throws Exception {
        String webPort = System.getenv("PORT");
        if (webPort == null || webPort.isEmpty()) {
            webPort = "8080";
        }

        JettyServer server = new JettyServer(Integer.parseInt(webPort));
        server.registerServlet(WelcomeServlet.class, "/welcome");
        server.registerServlet(ResourceServlet.class, "/resource");
        server.registerServlet(RoomServlet.class, "/room");
        server.registerServlet(QueryServlet.class, "/query");
        server.start();
        System.out.println("Hello World!");
    }
}
