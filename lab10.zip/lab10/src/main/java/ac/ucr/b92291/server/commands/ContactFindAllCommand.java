package ac.ucr.b92291.server.commands;


import ac.ucr.b92291.common.json.Json;
import ac.ucr.b92291.service.ContactService;

public class ContactFindAllCommand implements Command {
    @Override
    public String execute(String payload) {
        ContactService service = new ContactService();
        return Json.convert(service.findAll());
    }
}