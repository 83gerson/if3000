package ac.ucr.b92291.common.async;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

//la única clase para ejecutar hilos
public class AsyncManager {

    private static final ExecutorService service = Executors.newCachedThreadPool();

    public static <V> void execute(Async<V> process) {
        service.execute(() -> {
            try {
                //ejecutar
                V result = process.execute();

                //exitoso
                process.onSuccess(result);
            } catch (Throwable ex) {
                //fallo
                process.onFail(ex);
            }
        });
    }

}
