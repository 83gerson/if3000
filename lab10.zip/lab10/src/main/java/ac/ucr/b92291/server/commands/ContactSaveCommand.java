package ac.ucr.b92291.server.commands;


import ac.ucr.b92291.common.json.Json;
import ac.ucr.b92291.domain.Contact;
import ac.ucr.b92291.service.ContactService;

public class ContactSaveCommand implements Command {
    @Override
    public String execute(String payload) {
        ContactService service = new ContactService();
        service.save(Json.toEntity(payload, Contact.class));
        return "OK";
    }
}