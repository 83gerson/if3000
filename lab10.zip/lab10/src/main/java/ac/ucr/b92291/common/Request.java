package ac.ucr.b92291.common;


//record Request(String path, String payload){}
public class Request {
    // solicitando una acción
    private String path;
    //objeto convertido a JSON
    private String payload;

    public Request(String path, String payload) {
        this.path = path;
        this.payload = payload;
    }

    public Request() {
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public static class RequestBuilder {
        private String path;
        private String payload;

        public static RequestBuilder newBuilder() {
            return new RequestBuilder();
        }

        public RequestBuilder path(String path) {
            this.path = path;
            return this;
        }

        public RequestBuilder payload(String payload) {
            this.payload = payload;
            return this;
        }

        public Request build() {
            return new Request(path, payload);
        }

    }
}