package acucr.b92291;

import ac.ucr.b92291.domain.Contact;
import acucr.b92291.persistence.PersistenceContext;
import acucr.b92291.persistence.PersistenceStrategy;
import ac.ucr.b92291.service.ContactService;

import java.time.LocalDate;
import java.util.List;

/**
 * Gerson Cordero
 *
 */
public class App {

    public static void main(String[] args) {
        PersistenceContext.getInstance().setRoot("C:\\Users\\PC\\Desktop\\Gerson U\\Progra 2-2-2\\Ejemplo");
        PersistenceContext.getInstance().setStrategy(PersistenceStrategy.JSON);

        ContactService service = new ContactService();

        Contact c = new Contact();
        c.setBirthdate(LocalDate.now());
        c.setName("Miguel");
        c.setSurname("De Cervantes");
        service.save(c);
   List<Contact> contacts=  service.findAll();
   System.out.println(contacts);
   contacts.forEach(System.out::println);
    }
}
