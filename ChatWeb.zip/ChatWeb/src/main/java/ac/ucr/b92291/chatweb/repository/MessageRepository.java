/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.chatweb.repository;

/**
 *
 * @author Gerson Cordero
 */
import java.util.List;
import java.util.Objects;
import java.util.Vector;

public class MessageRepository {

    private List<Message> messages;

    private static MessageRepository instance;

    private MessageRepository() {
        messages = new Vector<>();
    }

    public static MessageRepository getInstance() {
        if (instance == null) {
            instance = new MessageRepository();
        }
        return instance;
    }

    public synchronized void add(Message message) {
        messages.add(message);
    }

    public List<Message> all() {
        return messages;
    }

    public static class Message {

        private final UserRepository.User user;
        private Integer id;
        private String value;

        public Message(String value, UserRepository.User user) {
            this.value = value;
            this.user = user;
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public UserRepository.User getUser() {
            return user;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            Message message = (Message) o;
            return Objects.equals(id, message.id);
        }

        @Override
        public int hashCode() {
            return Objects.hash(id);
        }
    }

}
