/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.common;

/**
 *
 * @author Gerson Cordero
 */
//Record Request (String path, String payload)
public class Request {

    //Solicito una acción
    private String path;
    //Objeto convertido a JSON
    private String payload;

    public Request(String path, String payload) {
        this.path = path;
        this.payload = payload;
    }

    public Request() {
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public static class requestBuilder {

        private String path;
        private String payload;

        public static requestBuilder newBuilder() {
            return new requestBuilder();
        }

        public requestBuilder path(String path) {
            this.path = path;
            return this;
        }

        public requestBuilder payload(String payload) {
            this.payload = payload;
            return this;
        }

        public Request build() {
            return new Request(path, payload);
        }

    }

}
