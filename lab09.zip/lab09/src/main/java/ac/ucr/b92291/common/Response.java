/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b92291.common;

/**
 *
 * @author Gerson Cordero
 */
public class Response {

    //OK, ERROR -> Enum
    private String type;
    // OK: El payload va a contener la respuesta esperada
    //ERROR: Tendrá algun mensaje o excepcion
    private String payload;

    public Response(String type, String payload) {
        this.type = type;
        this.payload = payload;
    }

    public Response() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public static class ResponseBuilder {

        private String type;
        private String payload;

        public static ResponseBuilder newBuilder() {
            return new ResponseBuilder();
        }

        public ResponseBuilder isSuccess() {
            type = "OK";
            return this;
        }

        public ResponseBuilder isError() {
            type = "ERROR";
            return this;
        }

        public ResponseBuilder withPayload(String payload) {
            this.payload = payload;
            return this;
        }

        public Response build() {
            return new Response(type, payload);
        }
    }

}
