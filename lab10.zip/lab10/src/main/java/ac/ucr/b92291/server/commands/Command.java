package ac.ucr.b92291.server.commands;

public interface Command {

    <R> R execute(String payload);
}