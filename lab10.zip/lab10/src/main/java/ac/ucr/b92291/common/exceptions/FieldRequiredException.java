package ac.ucr.b92291.common.exceptions;


public class FieldRequiredException extends RuntimeException {
    private String field;

    public FieldRequiredException(String field) {
        this.field = field;
    }

    public String getField() {
        return field;
    }
}