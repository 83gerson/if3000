/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.B92291.hw01; // TODO Recuerde actualizar el paquete con sus datos

import java.time.LocalDate;

public class LotteryNumber {

    public LotteryNumber(int number, LocalDate LD) {
        this.number = number;
    }
    
    // TODO Definir nuevo parámetro(Parte 2)
    static LotteryNumber third = new LotteryNumber(2, LocalDate.MAX);
    static LotteryNumber quarter = new LotteryNumber(2, LocalDate.MAX);
    LotteryNumber next = null;
    LocalDate localDate = LocalDate.now();
    int number = 0;

    public void add(LotteryNumber next) {
        if (this.next == null) {
            this.next = next;
        } else {
            this.next.add(next);
        }
    }

    public boolean find(int number) {
        if (this.number == number) {
            return true;
        } else {
            if (this.next != null) {
                return next.find(number);
            } else {
                return false;
            }
        }
    }

    public void print() {
// TODO Modificar el print (Parte 2)
        System.out.println(toString());
        if (next != null) {
            next.print();
        }
    }

    public LotteryNumber searchGreaterThan(Integer value) {
// TODO Implementar búsqueda por el value( Parte 1)
        if (number > value) {

            third.add(new LotteryNumber(number, LocalDate.MAX));
        }
        if (next != null) {
            this.next.searchGreaterThan(value);

        }
        return third;
    }

    public LotteryNumber searchLowerThan(Integer value) {
// TODO Implementar búsqueda por el value( Parte 1)

        if (number < value) {

            quarter.add(new LotteryNumber(number, LocalDate.MAX));
        }
        if (next != null) {
            this.next.searchLowerThan(value);

        }
        return quarter;
    }

// TODO Sobreescribir toString(Parte 2)
    @Override
    public String toString() {
        return "LotteryNumber{" + number + ", " + localDate + '}';
    }

}
