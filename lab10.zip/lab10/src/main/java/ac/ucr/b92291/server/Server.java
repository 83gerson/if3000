package ac.ucr.b92291.server;


import ac.ucr.b92291.common.Request;
import ac.ucr.b92291.common.Response;
import ac.ucr.b92291.common.async.AsyncRunner;
import ac.ucr.b92291.common.json.Json;
import ac.ucr.b92291.server.commands.MappingCommands;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public Server(int port) {
        ServerSocket serverSocket = null;
        try {
            serverSocket = new ServerSocket(port);
            while (true) {
                System.out.println("Esperando una conexión");
                Socket socket = serverSocket.accept();
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                String request = (String) in.readObject();
                processRequest(request, socket);
            }
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            if (serverSocket != null) {
                try {
                    serverSocket.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    private void processRequest(String rawRequest, Socket socket) {
        AsyncRunner.newRunner().onExecute(() -> {
            Request request = Json.toEntity(rawRequest, Request.class);
            String payload = MappingCommands.getCommand(request.getPath())
                    .execute(request.getPayload());
            Response response = Response.ResponseBuilder.newBuilder()
                    .isSuccess()
                    .withPayload(payload)
                    .build();
            processResponse(response, socket);
            return null;
        }).onFail((e) -> {
            processResponse(
                    Response.ResponseBuilder.newBuilder()
                            .isError()
                            .withPayload("Error procesando la petición")
                            .build(),
                    socket);
        }).run();

    }

    private void processResponse(Response response, Socket socket) {
        try {
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            out.writeObject(Json.convert(response));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}