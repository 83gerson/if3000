/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.B92291.hw2;

import java.util.ArrayList;

/**
 *
 * @author Gerson Cordero
 */
public class App {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        ArrayList<Node> node = new ArrayList<Node>();

        Node node1 = new Node("Luis");
        Node node2 = new Node("Pedro");
        Node node3 = new Node("Sebastian");
        Node node4 = new Node("Lisbeth");
        Node node5 = new Node("Valeska");
        Node node6 = new Node("Piero");

        //Añade los nodos al arreglo
        node.add(node1);
        node.add(node2);
        node.add(node3);
        node.add(node4);
        node.add(node5);
        node.add(node6);

        //Tomando en cuenta los nodos uno por uno
        node1.add(node2);
        node1.add(node3);
        node1.add(node4);
        node1.add(node5);
     
        node2.add(node1);
        node2.add(node6);

        node3.add(node1);
        node3.add(node4);
        node3.add(node5);

        node4.add(node1);
        node4.add(node3);

        node5.add(node1);
        node5.add(node3);

        node6.add(node2);

        for (int i = 0; i < node.size(); i++) {
            if (i == 0 || i == 2 || i == 4) {
                node.get(i).opinionPositive();
                node.get(i).publish();
            }

            System.out.println(node.get(i).getPublishedOpinion());
        }

    }

}
